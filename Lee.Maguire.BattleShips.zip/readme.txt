I started by working out a class hierarchy for the ships. A base ship class with an interface to enforce the use of certain properties, and then extended specific classes for each ship type with their own attributes. 
I next worked on creating the gameboard using arrays to store each cell as well as the rules around the size of the board and generator for placing ships on the board when you begin the game. 
I then created methods to draw all of this to the screen in a presentable format then moved onto dealing with the input and game rules within the game manager class.
After completing the task I created tests for the input manager class to test some of the functionality.
