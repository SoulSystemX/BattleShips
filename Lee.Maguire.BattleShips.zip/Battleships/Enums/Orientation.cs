﻿namespace BattleShips
{
    public enum Orientation { Horizontal, Vertical };
}
