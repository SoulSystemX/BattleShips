﻿namespace BattleShips
{
    public enum Ships { Battleship, Destroyer }
}
